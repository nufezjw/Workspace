/**
 * creates and shows a simple GUI
 */
public class ShowFlowLayoutGUI
{
	public static void main(String [] args)
	{
		FlowLayoutGUI myGUI = new FlowLayoutGUI();
		myGUI.setSize(400,300);
		myGUI.setVisible(true);
	}
}
