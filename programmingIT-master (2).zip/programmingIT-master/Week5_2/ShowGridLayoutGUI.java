/**
 A simple class to show a single frame
*/

public class ShowGridLayoutGUI
{  
	public static void main(String [] args)
	{
		GridLayoutGUI frame = new GridLayoutGUI();
		frame.setVisible(true);
	}
}
