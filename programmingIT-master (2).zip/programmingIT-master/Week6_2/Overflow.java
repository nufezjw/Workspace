public class Overflow {
   public static void main (String [] args) {
       System.out.println("65536 * 32769 = " + 65536 * 32769);
   }
}