/**
 * creates and shows a GUI
 */
public class ShowPrintTextGUI
{
	public static void main(String [] args)
	{
		PrintTextGUI myGUI = new PrintTextGUI();
		myGUI.setVisible(true);
	}
}
