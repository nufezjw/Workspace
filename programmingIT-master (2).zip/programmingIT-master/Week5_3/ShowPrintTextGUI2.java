/**
 * creates and shows a GUI
 */
public class ShowPrintTextGUI2
{
	public static void main(String [] args)
	{
		PrintTextGUI2 myGUI = new PrintTextGUI2();
		myGUI.setVisible(true);
	}
}
