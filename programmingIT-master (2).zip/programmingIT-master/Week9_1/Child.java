
public class Child implements Measurable{
	private int age;
	public Child(int a) {
		age = a;
	}
	
	public int getMeasure() {
		return age;
	}
	
}
