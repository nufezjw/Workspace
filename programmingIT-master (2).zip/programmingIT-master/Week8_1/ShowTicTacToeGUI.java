/**
 * creates and shows a GUI
 */
public class ShowTicTacToeGUI
{
	public static void main(String [] args)
	{
		TicTacToeGUI myGUI = new TicTacToeGUI();
		myGUI.setVisible(true);
	}
}