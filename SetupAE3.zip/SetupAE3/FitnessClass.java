/** Defines an object representing a single fitness class
 */
public class FitnessClass implements Comparable<FitnessClass> {
    // your code here

    public int compareTo(FitnessClass other) {
	  return 0; // replace with your code
    }
}
